Readme
1. mysql -u root -p
2. input password of MySQL
3. Use <yourdatabase>
4. select * from categories

//Note- this command will DELETE all your contents of categories! 注意-以下命令将删掉你的所有栏目！请备份先！

5. delete from categories

6. paste the generated script here.  粘贴所有生成的MySQL script, 刷新网页，你就会看到所有新生成的栏目。

7. Done

Note: follow the format in config.txt including "end" string. 注意，在config.txt，“end”必须在第一行和最后一行，每一个栏目之间都用end相隔。



